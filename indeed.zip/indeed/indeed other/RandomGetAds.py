import numpy as np

class RandomGetAds:
	
	def __init__(self, list_of_ads):
		self.list_of_ads = list_of_ads
		self.len = len(list_of_ads)
		
	def get_random_ad(self):
		index = np.random.choice(range(self.len))
		ad = self.list_of_ads[index]
	    self.list_of_ads[index] = self.list_of_ads[self.len-1]
	    self.list_of_ads[self.len-1] = ad
		self.len -= 1
		return ad
		
	def get_random_ad2(self):
		index = np.random.choice(range(self.len), p=)
		ad = self.list_of_ads[index]
	    self.list_of_ads[index] = self.list_of_ads[self.len-1]
	    self.list_of_ads[self.len-1] = ad
		self.len -= 1
		return ad
		