package sorting;

import java.util.*;

public class RandomGetAds {
    Random r = new Random();
    int i = r.nextInt(100);


}
